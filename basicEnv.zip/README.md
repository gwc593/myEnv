# myEnv

my unix env backup
